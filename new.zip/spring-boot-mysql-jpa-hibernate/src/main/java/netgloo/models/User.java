package netgloo.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * Represents an User for this web application.
 */
@Entity
@Table(name = "users")
public class User {

  // ------------------------
  // PRIVATE FIELDS
  // ------------------------
  
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private int userid;
  
  @NotNull
  private String email;
  
  @NotNull
  private String username;

  // ------------------------
  // PUBLIC METHODS
  // ------------------------
  
  public User() { }

  public User(int userid) { 
    this.userid = userid;
  }

  public User(String email, String username) {
    this.email = email;
    this.username = username;
  }

  public long getId() {
    return userid;
  }

  public void setId(int userid) {
    this.userid = userid;
  }

  public String getEmail() {
    return email;
  }
  
  public void setEmail(String value) {
    this.email = value;
  }
  
  public String getName() {
    return username;
  }

  public void setName(String username) {
    this.username = username;
  }
  
} // class User
