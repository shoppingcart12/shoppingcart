package netgloo.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * Represents an User for this web application.
 */
@Entity
@Table(name = "files")
public class FileEntity {

  // ------------------------
  // PRIVATE FIELDS
  // ------------------------
  
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private int fileid;
  
  @NotNull
  private String filename;
  
  @NotNull
  private byte[] filedata;

  // ------------------------
  // PUBLIC METHODS
  // ------------------------
  
  public FileEntity() { }
  
  public FileEntity(int fileid) { 
	  this.fileid=fileid;
  }
  public FileEntity(String filename, byte[] filedata) { 
	  this.filename=filename;
	  this.filedata=filedata;
  }




public int getFileid() {
	return fileid;
}

public void setFileid(int fileid) {
	this.fileid = fileid;
}

public String getFilename() {
	return filename;
}

public void setFilename(String filename) {
	this.filename = filename;
}

public byte[] getFiledata() {
	return filedata;
}

public void setFiledata(byte[] filedata) {
	this.filedata = filedata;
}
  
} // class User
